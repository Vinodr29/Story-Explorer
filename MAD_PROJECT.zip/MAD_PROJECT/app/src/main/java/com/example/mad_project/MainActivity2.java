package com.example.mad_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    TextView textView;
    Button button;
    Button share_btn;
    Button next_btn,prev_btn;
    int position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        textView=findViewById(R.id.txt);
        button=findViewById(R.id.copy_btn);
        share_btn=findViewById(R.id.share_btn);
        next_btn=findViewById(R.id.next_btn);
        prev_btn=findViewById(R.id.prev_btn);

        //final String dStory=getIntent().getStringExtra("story");
        final String[] dStory=getIntent().getStringArrayExtra("story");
        position=getIntent().getIntExtra("position",0);

        textView.setText(dStory[position]);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard= (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip=ClipData.newPlainText("Text",dStory[position]);
                clipboard.setPrimaryClip(clip);

                Toast.makeText(MainActivity2.this,"copied",Toast.LENGTH_SHORT).show();
            }
        });
        share_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setAction(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_TEXT,dStory[position]);
                intent.setType("text/plain");
                intent=Intent.createChooser(intent,"Share by");
                startActivity(intent);
            }
        });
        next_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                position=(position+1)% dStory.length;
                textView.setText(dStory[position]);
            }
        });
        prev_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                position=(position-1)% dStory.length;
                textView.setText(dStory[position]);
            }
        });
    }
}
